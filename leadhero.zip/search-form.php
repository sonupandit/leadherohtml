<form class="search-form px-3" action="">
  <div class="sf-wrap">
    <div class="input-group mb-3">
      <input type="text" class="form-control" placeholder="Search by name, email or phone...">
      <div class="input-group-append">
        <button class="btn btn-outline-secondary d-flex" type="button">
          <span class="icon-magnifying-glass"></span>
        </button>
      </div>
    </div>
  </div>
</form> 
