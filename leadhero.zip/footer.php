         <footer class="c-footer">
          <div class="container-fluid"><a href="#">Lead Hero</a> &copy; Copyright <?php echo date("Y");?> All rights reserved.</div>        
        </footer>
      </div>
    </div>
    <!-- CoreUI and necessary plugins-->
    <script src="js-leadhero/coreui.bundle.min.js"></script>
    <!--[if IE]><!-->
    <script src="js-leadhero/svgxuse.min.js"></script>
    <!--<![endif]-->
    <script src="js-leadhero/app.bundle.js"></script>
  </body>
</html>
